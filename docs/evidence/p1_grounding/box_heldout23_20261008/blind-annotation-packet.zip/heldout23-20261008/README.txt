Held-out packet scope: annotate all 23 wrist images, init27–49. The archived rules/2 below are preserved byte-for-byte for region, visibility and polygon semantics. Their historical 50-image population and project-primary role do not describe this packet: this distinct held-out schema requires 23 images and an independent human annotator, with explicit no-model-output/no-AI-draft attestations. Independence is self-attested, not verified by software. Do not change region semantics or consult model results. Fixed-reference labels retain the same rules but are not scored in this BOX experiment.

Open index.html locally. No server or network needed.
Only raw RGB is supplied; zero labels or model predictions are supplied.
Complete both entities on every image, then export annotations.complete.json.
Empty/partial exports cannot enter evaluation. Labels never enter runtime.
Validate: python -m embodied_runtime.experiments.p1_heldout_annotation_packet validate --packet PACKET --annotations annotations.complete.json
