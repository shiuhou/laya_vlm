Open index.html: original RGB only, zero supplied labels. Label drawer-front and fixed reference.
This temporal packet has a distinct schema and must not be loaded as the static 50-frame evaluation.
Sampled polygons cannot certify continuity. Inspect full raw recordings for event coverage, identity continuity,
occlusion/reappearance and lineage breaks; no model ROI or algorithm overlay may be shown for annotation.
Raw recording paths and hashes are preserved in manifest.json. No automatic interpolation of labels.
Human labels are evaluation-only, never a policy/tracker seed.
