Portable metadata + raw contact-sheet review evidence; full RGB-D blobs and raw-only MP4s remain local.
Frozen code fb2b2994525a3796d23939de310927e8e6712cde; registration228482f.
Original default-device T01/T02 rendering failure preserved under failed-default-device. Explicit software-device7 correction registered before ten new independent fresh acquisitions.
Every evaluator.jsonl is EVALUATOR-ONLY: original controls, simulator contacts and fixture assignments MUST NOT be consumed by perception/policy.
Perception analysis used empty sensor_geometry_seed sets; every chain UNSEEDED; zero tracker initialization; VERIFY UNKNOWN.
Raw sheets were reviewed by an AI agent, not independent human annotation. Temporal human packet has zero completed annotations.
Full raw source files / frame blobs / raw-only videos indexed in artifact-index.json with SHA256; no blobs/videos included in this portable archive.
Ten recorded cases are not ten target-valid sequences: T03–06/T10 unsupported; zero qualifying sequences.
