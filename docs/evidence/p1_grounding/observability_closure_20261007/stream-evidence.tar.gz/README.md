# P1 continuous geometry cost diagnostic

This is fresh static RGB-D capture plus exhaustive sensor surface/reference-hypothesis inventory. It is **not target tracking throughput**: no source-bound semantic seed exists, all target identities remain UNKNOWN, all valid-target publication counts are zero, and no tracker initialized. Archived BOX coordinates are separately named fixed search windows, never identity or source bindings for current frames. Full-frame context is an explicit additional workload.

All three processes requested 10 Hz for 30 seconds, dual 384×256 cameras, unchanged geometry config. CPU Mesa EGL software device7 selected explicitly; BLAS/OMP/MKL/Numba threads1. Mesa renderer creates additional driver threads. No post-reset actions, models, annotations, official success, query or gate changes.

| Init | Captured bundles | Snapshots incl drain | Replacements | In-window snapshot Hz | Pipeline p50 / p95 seconds | Diagnostic wall-age p50 / p95 seconds |
|---|---:|---:|---:|---:|---|---|
| 0 | 114 | 2 | 112 | 0.03333 | 26.513 / 26.698 | 27.016 / 27.690 |
| 12 | 112 | 3 | 109 | 0.03333 | 26.841 / 26.857 | 27.478 / 55.843 |
| 24 | 113 | 2 | 111 | 0.00000 | 32.780 / 33.456 | 36.536 / 39.447 |

All 14 published view-age measurements violate the existing 0.3-second free-space freshness bound. Static sim-age is zero; wall-age is retained and controls conservative freshness. The one pending bundle is replaced atomically across both cameras; captured = published + replaced, verified in each process. All seven persisted frame/identity records replayed with checksum validation.

The agentview full-frame inventory+candidate construction dominates the measured workload (~18–21 seconds in the first snapshots). The first init0 stage split was 10.457 s surface inventory + 9.959 s candidate geometry; wrist full-frame split 3.056 + 1.551 s. Named BOX search costs were only 0.194–0.577 s in init0, which are not end-to-end rates. Complete per-search/stage timings, queue age, publication gaps and raw candidates are retained in cycles.jsonl.

Publication occurs before frame persistence; complete measurement summaries for init12/24 distinguish publication-window rate, frame-persisted-window rate, journaled-window rate and drain-complete rate. Init0 failed only during final histogram serialization, after capture and two durable snapshots. Its offline observed-summary recovers exact logged statistics and marks unavailable run-end/journal metrics null rather than guessing.

## Operational and reporting boundaries

The initial separate root `observability-closure-stream-20261007` failed EGL initialization before capture: Mesa device0 was hardware. That evidence was sealed before independent device7 correction. `operational-registration.json` identifies the failure, enumerated device extensions, environment and unchanged code hashes.

Init0 used baseline fb2b299. It was not rerun. The isolated clean reporting-only revision eb39068 changes the histogram keys from booleans to strings; init12/24 use that revision, with source hashes and exact delta recorded in reporting-only-registration.json. The temporary implementation-copying serialization test was removed after the runs; actual successful init12/24 canonical summary serialization is the necessary reporting regression evidence. The four original targeted stream tests remain. No capture, queue, processing, geometry or timing code changed.

Raw sensor images have been inspected: both cameras show the intended static tabletop/cabinet scene. This is not a semantic identity annotation or grounding result.

## Interpretation

Observed: exhaustive scene/ROI hypothesis construction at every snapshot is far below the requested rate and produces stale geometry under this cost condition.

Not established: target-specific continuous tracking performance, reference observability, drawer-relative VERIFY, or action usability. This diagnostic cannot support Gate A/B by itself and cannot be used to claim that a seeded tracker would have the same cost.
