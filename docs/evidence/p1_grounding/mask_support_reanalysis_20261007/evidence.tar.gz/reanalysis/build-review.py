from pathlib import Path
from PIL import Image,ImageDraw
import json
from embodied_runtime.experiments.p1_segmentation_probe import verify_seal
root=Path("runs/p1/mask-support-reanalysis-20261007")
verify_seal(root/"geometry")
old=Path("runs/p1/box-sam2-grid-complete-20261007/review")
rows=json.loads((root/"geometry/results.json").read_text())
canvas=Image.new("RGB",(384*4,328*2),"#151515")
for ri,row in enumerate(rows):
 for col in range(4):
  init=row["init_index"]
  filename=f"init-{init:03d}-raw.png" if col==0 else f"init-{init:03d}-mask-{col-1}-overlay.png"
  im=Image.open(old/filename).convert("RGB")
  panel=Image.new("RGB",(384,328),"#151515");d=ImageDraw.Draw(panel)
  if col==0:lines=[f"init{init}: original RGB; no human label", "Original BOX/depth/source frozen", "Geometry remains original BOX domain"]
  else:
   est=row["native_mask_estimates"][col-1];p=est["patch"];m=p["metrics"]
   lines=[f"mask{col-1}: availability {100*m['depth_availability']:.1f}%",f"BOX coverage {100*m['mask_original_box_coverage']:.3f}% (diagnostic)",f"{p['geometry_status']}: depth-component ambiguity",f"candidates{len(p['candidates'])}; semantic identity UNKNOWN"]
  for j,line in enumerate(lines):d.text((4,16*j),line,fill="white")
  panel.paste(im,(0,72));canvas.paste(panel,(col*384,ri*328))
canvas.save(root/"all-masks-reanalysis.png")
