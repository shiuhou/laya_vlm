from pathlib import Path
import hashlib,json,numpy as np
from PIL import Image,ImageDraw
from embodied_runtime.experiments.p1_segmentation_probe import read,verify_seal,view_for
from embodied_runtime.perception.recording import project_base_points
root=Path("runs/p1/box-sam2-grid-complete-20261007")
verify_seal(root/"boxes");verify_seal(root/"masks");verify_seal(root/"geometry")
out=root/"review";out.mkdir(exist_ok=False)
rows=read(root/"geometry/results.json");meta=read(root/"masks/outputs.json")
w,h=384,256;header=54;canvas=Image.new("RGB",(4*w,2*(h+header)),"#151515")
index=[]
for rowidx,(r,m) in enumerate(zip(rows,meta)):
 view,_=view_for(read(root/"registration.json")["source"],r["init_index"])
 rgb=view["rgb"];Image.fromarray(rgb).save(out/f"init-{r['init_index']:03d}-raw.png")
 with np.load(m["artifact_uri"],allow_pickle=False) as data:
  for col in range(4):
   pixels=rgb.copy();desc=[f"init{r['init_index']} raw RGB; original BOX", "No annotation / no selected mask"]
   if col:
    mask=data["masks"][col-1]
    pixels[mask]=np.round(.60*pixels[mask]+.40*np.array([0,255,255])).astype(np.uint8)
    est=r["native_mask_estimates"][col-1];p=est["patch"]
    desc=[f"mask{col-1} native order; IoU={m['predicted_ious'][col-1]:.3f} uncalibrated",
          f"occupancy {100*est['mask_occupancy_inside_original_roi']:.2f}%; {p['reason_codes'][0]}",f"candidates={len(p['candidates'])}; no winner"]
   image=Image.fromarray(pixels);d=ImageDraw.Draw(image)
   box=m["box_xyxy"];d.rectangle(tuple(box),outline=(255,200,0),width=1)
   if col and p["candidates"]:
    points=np.array([c["position_base_m"] for c in p["candidates"]]);uv=project_base_points(points,view["intrinsics_K"],view["T_base_camera"])
    for x,y in uv:d.ellipse((x-2,y-2,x+2,y+2),fill=(255,0,0))
   panel=Image.new("RGB",(w,h+header),"#151515");pd=ImageDraw.Draw(panel)
   for i,line in enumerate(desc):pd.text((4,i*16),line,fill="white")
   panel.paste(image,(0,header));canvas.paste(panel,(col*w,rowidx*(h+header)))
   if col:
    image.save(out/f"init-{r['init_index']:03d}-mask-{col-1}-overlay.png")
    Image.fromarray(mask.astype(np.uint8)*255).save(out/f"init-{r['init_index']:03d}-mask-{col-1}-native.png")
   index.append(dict(init=r["init_index"],native_mask_index=col-1 if col else None,model_prediction_presealed=True,evaluation_annotation_used=False))
canvas.save(out/"all-masks-contact-sheet.png")
with (out/"index.json").open("x") as f:json.dump(dict(panels=index,files_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name != "index.json"},candidate_overlay_count=0,mask_winner=None,review_type="development visualization; no independent evaluation labels"),f,indent=2)
print(out/"all-masks-contact-sheet.png")
