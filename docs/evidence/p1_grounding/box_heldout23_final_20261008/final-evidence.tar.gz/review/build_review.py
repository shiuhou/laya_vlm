"""Postseal offline visual review: never calls a model, SAM, or geometry estimator."""
from pathlib import Path
import json,csv,hashlib,shutil
import numpy as np
from PIL import Image,ImageDraw
from embodied_runtime.experiments.p1_segmentation_probe import verify_seal,seal
root=Path('runs/p1/box-heldout23-20261008')
verify_seal(root/'scoring')
rows=json.loads((root/'scoring/rows.json').read_text())
truth=json.loads((root/'annotation-correction/annotations.metadata-corrected.json').read_text())
labels={r['image_id']:r for r in truth['annotations']}
packet=Path('/home/junhongli/projects/laya/p1_annotations_inbox/heldout23-20261008')
geo=json.loads((root/'geometry/results.json').read_text())
out=root/'review'
out.mkdir(exist_ok=False)
shutil.copyfile('/tmp/build_ho23_review.py',out/'build_review.py')
boxrows=[];nativerows=[];tiles=[];masktiles=[]
def label_draw(im,row):
    d=ImageDraw.Draw(im)
    for polygon in labels[row['image_id']]['entities']['drawer_front_pushable']['polygons']:
        d.line([tuple(p) for p in polygon]+[tuple(polygon[0])],fill='orange',width=2)
    return d
for r in rows:
    init=r['init_index']
    raw=Image.open(packet/f'images/{init:03d}.png').convert('RGB')
    im=raw.copy();d=label_draw(im,r)
    for arm,color in [('A','cyan'),('B','magenta')]:
        for b in r['arms'][arm]['boxes']:
            if b['box_xyxy']:
                d.rectangle(b['box_xyxy'],outline=color,width=2)
                bm=b['box_metrics']
                boxrows.append(dict(init_index=init,arm=arm,box_index=b['box_index'],box_xyxy=str(b['box_xyxy']),**bm))
    p=r['point']['point_xy']
    if p:
        x,y=p;d.ellipse((x-4,y-4,x+4,y+4),outline='yellow',width=2)
    tile=Image.new('RGB',(768,320),'#181818');tile.paste(raw,(0,48));tile.paste(im,(384,48))
    td=ImageDraw.Draw(tile)
    td.text((5,3),f'init{init}  RAW | orange: human region; cyan A BOX; magenta B BOX; yellow POINT',fill='white')
    td.text((5,18),f"POINT: {r['point']['reason'] or 'TYPED'}; inside={r['point']['inside_human_region']}",fill='white')
    td.text((5,32),'A: '+str(r['arms']['A']['reason'] or 'TYPED')+' | B: '+str(r['arms']['B']['reason'] or 'TYPED'),fill='white')
    tile.save(out/f'frame-{init:03d}.png');tiles.append(tile)
    for arm in ['A','B']:
        for b in r['arms'][arm]['boxes']:
            if not b['masks']:continue
            source=next(g for g in geo if g['init_index']==init and g['arm']==arm and g['box_index']==b['box_index'])
            with np.load(source['artifact_uri'],allow_pickle=False) as data:
                for n in b['masks']:
                    ordinal=n['native_mask_ordinal'];m=data['masks'][ordinal]
                    arr=np.array(raw).copy();arr[m]=(arr[m]*.55+np.array([50,100,255])*.45).astype(np.uint8)
                    mi=Image.fromarray(arr);md=label_draw(mi,r)
                    for c in n['candidates']:
                        if c['image_xy']:
                            x,y=c['image_xy'];md.point((int(round(x)),int(round(y))),fill='lime' if c['inside_annotated_region'] else 'red')
                    mt=Image.new('RGB',(768,320),'#181818');mt.paste(raw,(0,48));mt.paste(mi,(384,48));md=ImageDraw.Draw(mt)
                    md.text((5,3),f'init{init} {arm} native{ordinal} blue mask; red outside proposals; orange human',fill='white')
                    md.text((5,18),f"containment={n['mask_point_admission']['admitted']}; geometry={n['geometry_category']}",fill='white')
                    md.text((5,32),f"{n['evaluation_category']}; candidates={len(n['candidates'])}",fill='white')
                    mt.save(out/f'mask-{init:03d}-{arm}-{ordinal}.png');masktiles.append(mt)
                    nativerows.append(dict(init_index=init,arm=arm,ordinal=ordinal,point_contained=n['mask_point_admission']['admitted'],geometry_category=n['geometry_category'],evaluation_category=n['evaluation_category'],reasons=';'.join(n['reason_codes']),raw_candidates=len(n['candidates']),inside=n['task_valid_candidate_count'],outside=n['outside_region_candidate_count'],**n['mask_overlap']))
for name,records in [('box-metrics',boxrows),('native-metrics',nativerows)]:
    with (out/f'{name}.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
for label,items in [('frames',tiles),('masks',masktiles)]:
    for start in range(0,len(items),6):
        batch=items[start:start+6];sheet=Image.new('RGB',(1536,320*((len(batch)+1)//2)),'#181818')
        for i,t in enumerate(batch):sheet.paste(t,((i%2)*768,(i//2)*320))
        sheet.save(out/f'{label}-sheet-{start//6+1}.png')
(out/'receipt.json').write_text(json.dumps({'scoring_seal_sha256':hashlib.sha256((root/'scoring/sealed.json').read_bytes()).hexdigest(),'frames':len(tiles),'native_masks':len(masktiles),'typed_boxes':len(boxrows),'all_candidates_rendered_no_winner':True,'labels_evaluation_only':True,'warning':'Orange polygons are conservative human usable-region annotations; outside is not necessarily physically wrong object.'},indent=2)+'\n')
seal(out)
print(out)
