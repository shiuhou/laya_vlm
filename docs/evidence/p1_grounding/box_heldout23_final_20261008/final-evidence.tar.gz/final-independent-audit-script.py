import json,hashlib,sys,csv,collections
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/junhongli/projects/laya/laya-embodied-runtime')
from embodied_runtime.experiments.p1_segmentation_probe import verify_seal
R=Path('/home/junhongli/projects/laya/laya-embodied-runtime/runs/p1/box-heldout23-20261008')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def ck(k,v):
 checks.append({'check':k,'pass':bool(v)})
 if not v:print('FAIL',k)
def contains(points,polygons):
 points=np.asarray(points);px,py=points[:,0],points[:,1];answer=np.zeros(len(points),bool)
 for poly in polygons:
  inner=np.zeros(len(points),bool)
  for a,b in zip(poly,poly[1:]+poly[:1]):
   ax,ay=a;bx,by=b
   if by!=ay:inner^=((ay>py)!=(by>py)) & (px<(bx-ax)*(py-ay)/(by-ay)+ax)
  answer|=inner
 return answer
for s in ['capture','grounding','masks','geometry','scoring','annotation-correction']:verify_seal(R/s);ck(s+'_seal',True)
prior=read(R/'independent-audit.json');cond=read(R/'scoring/condition.json');orig=read(R/'annotation-receipts/8a701062ed90f013/annotations.complete.json');corr=read(R/'annotation-correction/annotations.metadata-corrected.json');receipt=read(R/'annotation-correction/correction-receipt.json');rows=read(R/'scoring/rows.json');summary=read(R/'scoring/summary.json');geos=read(R/'geometry/results.json');calls=read(R/'grounding/outputs.json');capture=read(R/'capture/manifest.json');sources={x['image']['init_index']:x for x in capture['inputs']};truth={x['image_id']:x for x in corr['annotations']}
ck('generation_seals_identical_to_prelabel_audit',all(prior['source_sha256'][s+'_seal']==sha(R/s/'sealed.json')==cond['generation_seals'][s] for s in ['capture','grounding','masks','geometry']))
ck('annotation_original_preserved',sha(R/'annotation-receipts/8a701062ed90f013/annotations.complete.json')==receipt['original_sha256'])
ck('annotation_corrected_hash_bound',sha(R/'annotation-correction/annotations.metadata-corrected.json')==receipt['corrected_sha256']==cond['annotation_receipt']['annotation_file_sha256'])
ck('annotation_all_records_unchanged',orig['annotations']==corr['annotations'])
ck('annotation_only_documented_metadata_changed',sorted(k for k in set(orig)|set(corr) if orig.get(k)!=corr.get(k))==sorted(receipt['changed_keys']))
ck('all23canonicalrows',[x['init_index'] for x in rows]==list(range(27,50)))
ck('all46arms',sum(len(x['arms']) for x in rows)==46 and all(set(x['arms'])=={'A','B'} for x in rows))
ck('23humanrecords',len(truth)==23)
geo={(x['init_index'],x['arm'],x['box_index']):x for x in geos};call={(x['init_index'],x['kind']):x for x in calls};Y,X=np.indices((256,384));samples=np.column_stack([X.ravel()+.5,Y.ravel()+.5]);aggregate=collections.Counter();box_evaluated=collections.Counter();box_correct=collections.Counter();point_inside=0
for row in rows:
 i=row['init_index'];src=sources[i];t=truth[row['image_id']]['entities']['drawer_front_pushable'];polys=t['polygons'];label=contains(samples,polys).reshape(256,384);ys,xs=np.nonzero(label);bbox=[xs.min(),ys.min(),xs.max()+1,ys.max()+1];point=call[i,'POINT'];ck(f'{i}_visibility',row['human_status']==t['status'])
 if point['source_admitted']:
  inside=bool(contains([point['point_xy']],polys)[0]);ck(f'{i}_point_membership',inside==row['point']['inside_human_region']);point_inside+=inside
 for arm in ['A','B']:
  a=row['arms'][arm];c=call[i,arm];ck(f'{i}_{arm}_all_box_slots',len(a['boxes'])==max(1,len(c['ordered_boxes'])));pool=[];admitted=[]
  for b in a['boxes']:
   g=geo[i,arm,b['box_index']];ck(f'{i}_{arm}_{b["box_index"]}_box_receipt',b['box_xyxy']==g['box_xyxy'])
   if b['box_xyxy'] is not None:
    box_evaluated[arm]+=1;box=b['box_xyxy'];mask=(X+.5>=box[0])&(X+.5<box[2])&(Y+.5>=box[1])&(Y+.5<box[3]);overlap=int((mask&label).sum());coverage=overlap/int(label.sum());purity=overlap/int(mask.sum());inter=max(0,min(box[2],bbox[2])-max(box[0],bbox[0]))*max(0,min(box[3],bbox[3])-max(box[1],bbox[1]));iou=inter/((box[2]-box[0])*(box[3]-box[1])+(bbox[2]-bbox[0])*(bbox[3]-bbox[1])-inter);met=b['box_metrics'];correct=coverage>=.9 and iou>=.5;box_correct[arm]+=int(correct)
    ck(f'{i}_{arm}_box_metrics_independent_of_point',np.allclose([coverage,purity,iou],[met['annotated_coverage'],met['annotated_purity'],met['human_support_bbox_iou']],rtol=0,atol=1e-12) and correct==met['localization_correct'])
   ck(f'{i}_{arm}_all_native_masks',[n['native_mask_ordinal'] for n in b['masks']]==[n['ordinal'] for n in g['native_results']])
   for n,gn in zip(b['masks'],g['native_results']):
    candidates=gn['estimate']['patch']['candidates'];ck(f'{i}_{arm}_{n["native_mask_ordinal"]}_no_winner_or_point_skip',[x['point_id'] for x in n['candidates']]==[x['point_id'] for x in candidates]);source=gn['estimate']['source_identity'];T=np.asarray(source['T_base_camera']);K=np.asarray(source['intrinsics_K']);pts=np.array([x['position_base_m'] for x in candidates]).reshape(-1,3);camera=(pts-T[:3,3])@T[:3,:3];projection=camera@K.T;uv=projection[:,:2]/projection[:,2:3];inside=contains(uv,polys)
    ck(f'{i}_{arm}_{n["native_mask_ordinal"]}_candidate_projection_and_membership',all(np.allclose(p,sc['image_xy'],atol=1e-9,rtol=0) and bool(ok)==sc['inside_annotated_region'] for p,ok,sc in zip(uv,inside,n['candidates'])))
    pool.extend(bool(v) for v in inside)
    if n['mask_point_admission']['admitted']:admitted.extend(bool(v) for v in inside)
  for kind,items in [('raw',pool),('admitted',admitted)]:
   p=a['pools'][kind];correct=sum(items);outside=len(items)-correct;ck(f'{i}_{arm}_{kind}_all_candidates_aggregate',p['total']==len(items) and p['correct']==correct and p['outside']==outside and p['unscored']==0 and p['clean']==bool(items and all(items)));aggregate[arm,kind,'total']+=len(items);aggregate[arm,kind,'correct']+=correct;aggregate[arm,kind,'outside']+=outside
for arm in ['A','B']:
 ck(arm+'_23frame_denominators',all(summary['arms'][arm][k]['denominator']==23 for k in ['typed','complete_eos','box_localization_all','box_localization_visible','clean_all','clean_visible']))
 ck(arm+'_box_count_reconciles',summary['arms'][arm]['box_localization_all']['n']==box_correct[arm])
 for kind in ['raw','admitted']:
  for metric in ['total','correct','outside']:ck(f'{arm}_{kind}_{metric}_summary',summary['arms'][arm]['candidate_counts'][kind][metric]==aggregate[arm,kind,metric])
ck('point_inside_summary',summary['point']['inside_all']['n']==point_inside and summary['point']['inside_all']['denominator']==23)
ck('paired_full23_and_common0',summary['paired']['clean_all']['denominator']==23 and summary['paired']['box_localization_visible']['denominator']==23 and summary['paired']['clean_common_sam']['denominator']==0)
with (R/'scoring/all23.csv').open() as f:csvrows=list(csv.DictReader(f))
ck('CSV23canonical',[int(x['init_index']) for x in csvrows]==list(range(27,50)))
report={'status':'PASS' if all(x['pass'] for x in checks) else 'FAIL','scope':'Final scoring audit, no new generation or geometry execution','checks':checks,'checks_count':len(checks),'all23_scene_denominator':23,'arm_frame_slots':46,'typed_BOX_metrics_evaluated_regardless_of_POINT':dict(box_evaluated),'BOX_localization_correct':dict(box_correct),'POINT_inside_human_regions':point_inside,'candidate_counts':{a:{k:{m:aggregate[a,k,m] for m in ['total','correct','outside']} for k in ['raw','admitted']} for a in ['A','B']},'annotation_provenance':'Explicit user-attested human independence; original contradictory export and metadata-only correction preserved. Not independently verified.','limitations':['BOX IoU uses bounding box of conservative human pushable support, not exhaustive physical front-panel outline; localization rejection must not be equated with proof of absent drawer-front coverage.','Outside-human-region counts mean outside this frozen evaluation support; they do not independently prove physical wrong-part identity over all unannotated pixels.','POINT zero correct among four typed samples blocks full automatic chain; B has zero SAM generation, so no comparative SAM quality claim is identifiable.','All23 were human VISIBLE; no broader viewpoint/temporal/generalization or real-sensor claim.','Runtime candidate usability remains UNKNOWN; evaluation membership is not execution feasibility.'],'evidence_sha256':{'prior_independent_audit':sha(R/'independent-audit.json'),'scoring_seal':sha(R/'scoring/sealed.json'),'annotation_correction_seal':sha(R/'annotation-correction/sealed.json'),'audit_script':sha('/tmp/laya-heldout-final-audit.py')}}
with (R/'final-independent-audit.json').open('x') as f:json.dump(report,f,indent=2)
print(report['status'],len(checks),dict(box_evaluated),report['candidate_counts'])
