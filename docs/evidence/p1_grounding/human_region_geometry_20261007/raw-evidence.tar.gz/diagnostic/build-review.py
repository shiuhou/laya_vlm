"""Post-evaluation display only; no geometry recomputation or target selection."""
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from embodied_runtime.experiments.p1_segmentation_probe import read,write,seal,verify_seal
from embodied_runtime.experiments.records import file_hash
ROOT=Path('runs/p1/human-region-geometry-20261007')
for stage in ('inputs','geometry','summary'):verify_seal(ROOT/stage)
r=read(ROOT/'registration.json');rows=read(ROOT/'geometry/results.json')
out=ROOT/'review';out.mkdir(exist_ok=False);sheets=[];inventory=[]
for row in rows:
 image=row['image'];w,h=image['width'],image['height'];m=row['report']
 rgb=np.asarray(Image.open(Path(r['entry']['annotation_packet_manifest_path']).parent/image['image_path']).convert('RGB'))
 mask=np.load(row['mask_uri'],allow_pickle=False)
 overlay=rgb.copy();overlay[mask]=(.6*rgb[mask]+.4*np.array([255,0,100])).astype(np.uint8)
 sheet=Image.new('RGB',(w*2,h+96),'white');sheet.paste(Image.fromarray(rgb),(0,0));sheet.paste(Image.fromarray(overlay),(w,0));draw=ImageDraw.Draw(sheet)
 for poly in row['human_polygons']:
  pts=[(w+x,y) for x,y in poly];draw.line(pts+[pts[0]],fill='yellow',width=1)
 for u,v in row['candidate_image_xy']:draw.ellipse((w+u-2,v-2,w+u+2,v+2),fill='cyan')
 draw.text((2,h+2),f'init{image["init_index"]}: original wrist RGB',fill='black')
 draw.text((2,h+20),f'human support pixels: {row["human_region_pixels"]}; valid depth: {row["human_region_depth_availability"]:.0%}',fill='black')
 draw.text((2,h+38),f'plane support: {m["plane_support_ratio"]:.4f}; RMS: {m["plane_rms_m"]:.3e} m',fill='black')
 draw.text((2,h+56),f'sigma: {m["position_sigma_m"]*1000:.3f} mm; erosion: {m["erosion_m"]*1000:.3f} mm',fill='black')
 draw.text((2,h+74),f'eroded support: {m["eroded_support_count"]}; boundary points: {m["boundary_point_count"]}',fill='black')
 draw.text((w+2,h+2),'OFFLINE HUMAN SUPPORT UPPER BOUND',fill='red')
 draw.text((w+2,h+20),f'geometry candidates: {m["tool_interior_candidate_count"]}; first rejection: {m["first_rejection"]}',fill='black')
 draw.text((w+2,h+38),'pink: human support; cyan: raw candidates',fill='black')
 draw.text((w+2,h+56),'all candidate usability UNKNOWN; no runtime use',fill='black')
 draw.text((w+2,h+74),'original gates; no geometry recomputation for display',fill='black')
 sheets.append(sheet);inventory.append(dict(init_index=image['init_index'],page=image['init_index']//5))
 if len(sheets)==5:
  page=Image.new('RGB',(2*w,(h+96)*5),'white')
  for j,s in enumerate(sheets):page.paste(s,(0,j*(h+96)))
  page.save(out/f'page-{image["init_index"]//5:02}.png');sheets=[]
write(out/'inventory.json',dict(rows=inventory,evaluation_only=True,script_sha256=file_hash(ROOT/'build-review.py'),geometry_seal_sha256=file_hash(ROOT/'geometry/sealed.json')))
seal(out)
